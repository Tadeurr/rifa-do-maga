export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-100">
      <div className="bg-white p-8 rounded-xl shadow text-center">
        <h1 className="text-3xl font-bold text-blue-700">🎣 Rifa - Pescaria com Magnata</h1>
        <p className="mt-2 text-gray-700">Participe por apenas R$1,00 e concorra a uma experiência incrível de pesca!</p>
      </div>
    </div>
  )
}