export default function App() {
  return (
    <div className="p-4 text-center text-gray-900">
      <h1 className="text-3xl font-bold mb-2">Rifa - Pescaria com Magnata</h1>
      <p className="mb-4">Participe da rifa por apenas R$1,00!<br/>Prêmio: pescaria de tucunaré azul e amarelo com churrasco e cerveja!</p>
    </div>
  );
}
