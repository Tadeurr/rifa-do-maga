
function App() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-blue-100 text-blue-900 text-xl">
      <h1>Bem-vindo à Rifa Magnata!</h1>
    </div>
  );
}
export default App;
